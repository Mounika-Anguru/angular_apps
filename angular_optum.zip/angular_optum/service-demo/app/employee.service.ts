import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { IEmployee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

 // _url="/assets/data/employees.json";
 _url="http://localhost:3000/emp";

  constructor(private http:HttpClient) {}

    getEmployees():Observable<IEmployee[]>{
      return this.http.get<IEmployee[]>(this._url);
    }
  
}
