import { Component, OnInit } from '@angular/core';
import { CloneVisitor } from '@angular/compiler/src/i18n/i18n_ast';
import { Emp } from './emp';

@Component({
  //this is component created by command "ng generate component test "
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  status = true;
 
  message="Hello This Is Test Component";
  //JSON data

  displaylist = true;

  topics = ["Java","Python","AI","ML","Angular JS"];
  
  employees = [{"id":1,"name":"Mounika"},
  {"id":1,"name":"Dileep"},
  {"id":1,"name":"Sraveen"},
  {"id":1,"name":"Sandeep"},
  {"id":1,"name":"Siddhu"}];

  emp = new Emp(100,"Mounika","Hyderabad",65000);

  inputText= "";
  constructor() { }

  ngOnInit() {
  }
  onClick(event:Event){
    this.status = false;

    console.log();

    
  }
  onClick2(data){
  

    console.log(data);

    
  }
  
  
}
