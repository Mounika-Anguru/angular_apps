export class Emp{
      constructor(empId:number,name:string,city:string,salary:number){
          
      }
}