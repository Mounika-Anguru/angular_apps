import { Component } from '@angular/core';

@Component({
    //manually created component
    selector:'demo-app',
    template: `
            <h1>Hello Class,my component1</h1>
            <h2>{{message}}</h2>
        `,
    styles:[]
})
export class DemoComponent{
    message= "My First Component";
}